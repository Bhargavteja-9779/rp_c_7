#!/bin/bash
# Compile main.pdf and supplement.pdf (pdfLaTeX + BibTeX). Numbers and tables are pre-generated in tables/ (macros.tex etc.).
set -e
for i in 1 2; do pdflatex -interaction=nonstopmode supplement.tex >/dev/null || true; pdflatex -interaction=nonstopmode main.tex >/dev/null; bibtex main >/dev/null 2>&1 || true; done
pdflatex -interaction=nonstopmode main.tex >/dev/null; pdflatex -interaction=nonstopmode supplement.tex >/dev/null; pdflatex -interaction=nonstopmode main.tex >/dev/null
echo built
